package requestresult;

public class Request {

}
