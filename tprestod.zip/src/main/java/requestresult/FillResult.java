package requestresult;

/**
 * Outcome of the Fill Request
 */
public class FillResult extends Result {

    public FillResult(String message, boolean success) {
        super(message, success);
    }
}
