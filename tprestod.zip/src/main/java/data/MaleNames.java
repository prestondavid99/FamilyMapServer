package data;

public class MaleNames {
    private String[] data;

    public String[] getData() {
        return data;
    }
}
