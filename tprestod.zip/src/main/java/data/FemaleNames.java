package data;

public class FemaleNames {
    private String[] data;

    public String[] getData() {
        return data;
    }
}
