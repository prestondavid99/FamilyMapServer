package data;

public class LocationData {
    private Location[] data;

    public Location[] getData() {
        return data;
    }
}
