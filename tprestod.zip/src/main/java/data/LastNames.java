package data;

public class LastNames {
    private String[] data;

    public String[] getData() {
        return data;
    }
}
